 <?php
date_default_timezone_set("Europe/Lisbon");
echo "" . date("d-m-Y H:i:s");
?>